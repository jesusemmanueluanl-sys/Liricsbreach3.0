# Lyrics Bridge

Muestra en Minecraft (Java, Fabric 26.3, por ejemplo en Zalith Launcher) la letra sincronizada de lo que suena en YouTube, YouTube Music o Spotify en el mismo celular.

- `android-app/`: app Android. Lee la sesión multimedia del sistema, busca la letra en [LRCLIB](https://lrclib.net) y la publica en `http://127.0.0.1:8765/now` (solo local).
- `fabric-mod/`: mod de Fabric para Minecraft 26.3 (cliente). Consulta esa dirección y dibuja la letra en el HUD.

Licencia MIT (ver `LICENSE` y `NOTICE.md`). Proyecto no oficial; no afiliado a Mojang, Microsoft, Spotify ni Google.

## Compilar
**Con GitHub (recomendado):** sube este proyecto a un repositorio. El workflow `Build` (Actions) genera dos artefactos: `lyricsbridge-apk` y `lyricsbridge-mod`.
**Solo con el celular:** sube `lyricsbridge.zip` sin descomprimir a la raíz del repo, crea `.github/workflows/build-from-zip.yml` con el contenido del archivo `build-from-zip.yml` y ejecútalo en Actions.
**Local:** `gradle -p android-app assembleDebug` (JDK 17) y `gradle -p fabric-mod build` (JDK 25, Gradle 9.5.1).

## Usar
1. Instala `app-debug.apk`. Ábrela → "Dar acceso a notificaciones" y actívalo (si Android dice "ajuste restringido": Ajustes → Apps → Lyrics Bridge → ⋮ → Permitir ajustes restringidos).
2. "Quitar optimización de batería". Pon música y toca "Probar": debe salir el título y la línea actual.
3. Copia el `.jar` del mod (no el `-sources`) a la carpeta `mods` de tu instancia de Zalith, con Fabric API 0.161.0+26.3 o superior, Fabric Loader 0.19.5+ y Java 25.
4. Abre Minecraft con la canción sonando.

## Modos de letra
Por defecto la letra flota **en el mundo** frente a ti (se reacomoda cuando te das la vuelta). Argumentos JVM opcionales:
- `-Dlyricsbridge.mode=world|hud|both` (world = en el aire, hud = pegada a la pantalla, both = las dos)
- `-Dlyricsbridge.distance=5` (bloques frente a ti), `-Dlyricsbridge.height=0.5` (sobre tus ojos), `-Dlyricsbridge.scale=0.05` (tamaño)

## Ajustes
- Letra adelantada/atrasada: argumento JVM `-Dlyricsbridge.url=http://127.0.0.1:8765/now?offset=300` (ms).
- Puerto: `Bridge.DEFAULT_PORT` en la app y la URL en el mod.

## Privacidad
El servidor escucha solo en 127.0.0.1; otras apps del mismo celular podrían consultarlo. La app solo envía a LRCLIB título, artista, álbum y duración de la canción.
